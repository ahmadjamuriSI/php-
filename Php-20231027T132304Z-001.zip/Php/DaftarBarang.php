<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><br><br><br><br><br><br><br><br><br>
	<?php
	$conn = mysqli_connect( "localhost","root","","persediaandb");
	if (mysqli_connect_errno()){
		echo "Koneksi Gagal".mysqli_connect_error();
	}
	$query = mysqli_query($conn,"select * from barang");
	?><center>
	<table border="2">
	<tr>
		<td>Kode Barang</td>
		<td>Nama Barang</td>
		<td>Satuan</td>
		<td>Warna</td>
		<td>Jumlah</td> 
			<td> Hapus</td>
			<td> Edit</td>
			<td> Kembali</td>
	</tr>
	<?php
	while($row=mysqli_fetch_array ($query))
				{
					echo"<tr>";
					echo"<td>".$row["kdbarang"]."</td>";
					echo"<td>".$row["nmbarang"]."</td>";
					echo"<td>".$row["satuan"]."</td>";
					echo"<td>".$row["warna"]."</td>";
					echo"<td>".$row["jumlah"]."</td>";
					echo"<td><a href =Delete.php?kdbarang=".$row["kdbarang"].">Delete</a></td>";
					echo"<td><a href =EditBarang.php?kdbarang=".$row["kdbarang"].">Edit</a></td>";
					echo"<td><a href ='barang.php'>Back</a></td>";
					echo "</tr>";
				}
			?></center>
		</table>
	</body>
</html>