<html>
<body>
<?php
$conn = mysqli_connect ("localhost","root","","persediaandb");
if (mysqli_connect_errno()){
     echo "Koneksi Gagal".mysqli_connect_error();
}
$query = mysqli_query($conn,"select * from barang");
?>
<center>
<table width="800" height="300" border="1" bgcolor="#00ff99">
  <tr>
<td><table width="400" height="50" align="center" bgcolor="#999999">
</table>

<center>
<b><h3> PT. SISTEM INFORMASI </h3>
JL. Raya Serang Km.10 Bitung-Tangerang</b>
<hr>
<h3>LAPORAN DATA BARANG</h3>
<table border="1" cellpadding="5" cellspacing="0">
   <thead>
       <tr> 
	   <td>Kode Barang</td>
	   <td>Nama Barang</td>
	   <td>Satuan</td>
	   <td>Warna</td>
	   <td>Jumlah</td>
       </tr>
    </thead>
    <tbody>
    <?php
    while($row=mysqli_fetch_array ($query))

    {
echo"<tr>";
          echo"<td>".$row['kdbarang']."</td>";
	  echo"<td>".$row['nmbarang']."</td>";
	  echo"<td>".$row['satuan']."</td>";
	  echo"<td>".$row['warna']."</td>";
          echo"<td>".$row['jumlah']."</td>";
     echo"</tr>";

    }
    ?>
 </center>
    </body>
 </table><p>
 </center>

<p><p>
<br>
<center><div class="frame_footer  "><br><br><p>
<div class ="frame_inside_footer " style="background-color: #800000; color: #FFFFFF;">
<span class="style" style="color: #FFFFFF">copyright by ahmad jamuri</span><br class="style" />
<span class="style"><span class="style">&copy; 2023 all rights reserved</span></span><span class="style" />
</span>
</div>

</table>
<a href="menu.php">klik disini kembali ke menuutama</a>
</body>
</html>