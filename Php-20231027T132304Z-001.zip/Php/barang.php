<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
<title>Data Siswa</title>
</head>
<body><CENTER>
	<table width="1260" height="500" border="1" bgcolor="#00FF99">
		<tr>
			<td><table width="400" height="47" border="1" align="center" bgcolor="#999999">
				<center>
					<tr>
						<td width="400">INPUT DATA BARANG</td>

					</tr>
					<form method="post" action="insert.php">
			</table>
<table width="400" border="1" align="center" bgcolor="width">
	<tr>
		<td colspan="2">INPUT DATA BARANG </td>
	</tr>
<form method="post" action="insert.php">

	<tr>
		<td width="174">Kode Barang</td>
		<td><input name="txtkdbarang" type="text" id="txtkdbarang" size="5" /></td>
	</tr>

	<tr>
		<td>Nama Barang</td>
		<td><input name="txtnmbarang" type="text" id="txtnmbarang" size="25" /></td>
	</tr>
	<tr>
		<td>Satuan</td>	
		<td width="306"><select name="cbsatuan" id="txtsatuan">
			<option value="Pcs">Pcs</option>
			<option value="Set">Set</option>
			<option value="Box">Box</option>
			<option value="Pcs">Pcs</option>
			<option value="Kg">Kg</option>
				</select></td>
	  </tr>
	<tr>
		<td>Warna</td>
		  <td width="306"><select name="cbwarna" id="txtwarna">
			<option value="Hitam">Hitam</option>
			<option value="Biru">Biru</option>
			<option value="Putih">Putih</option>
			<option value="None">None</option>	
				</select></td>
	</tr>
<tr>
		<td>Jumlah</td>
		<td><input name="txtjumlah" type="text" id="txtjumlah" size="25" /></td>
	</tr>
	<tr><CENTER>
		<td colspan="2"><form id="form5" name="form5" method="post" action="">
		<input name="BtnSave" type="submit" id="BtnSave" value="save" />
		<input name="BtnBatal" type="reset" id="BtnBatal" value="cancel" />
 	</from>   </td></CENTER>
	
</body>
</html>

























